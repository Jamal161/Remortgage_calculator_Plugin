<?php
	
?>
<div style="float:none" class="well-3 center-block-3 col-md-4-3">
<h3>Help - User Guide</h3>

== <b>Description</b> ==
<p>

</p>


== <b>Main features:</b> ==
<p>
<ul>
<li>* Calculator Guide looks responsive on any device.</li>
<li>* You can use it as simple calculator with Loan amount, Down payment, Loan length, Annual Interest and Payment term.</li>
<li>* The calculator display results in block or Popup window with simple text.</li>
<li>* Use shortcode to add it to any page at backend or frontend.</li>
<li>* At backend or admin page, put ShortCode /*[calculator-guide]*/ to add calculator to the page. Please always remember 
to remove [/* */] from the Shortcode.</li>
<li>* At frontend, put ShortCode /*if ( shortcode_exists( 'calculator-guide' ) ) { echo do_shortcode('[calculator-guide]');} */ to 
add calculator to the page. Please always remember to remove [/* */] from the Shortcode.</li>
<li>* Click 'Settings' under 'calculator_guild' menu at admin page to select your option for display result.</li>
</ul>
</p>
</div>