CREATE TABLE IF NOT EXISTS `wc_calculator_guide` (
  `intid` int(11) NOT NULL AUTO_INCREMENT,
  `popbg` varchar(250) NOT NULL,
  PRIMARY KEY (`intid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;




INSERT INTO `wc_calculator_guide` (`intid`, `popbg`) VALUES (1, 'popup');


